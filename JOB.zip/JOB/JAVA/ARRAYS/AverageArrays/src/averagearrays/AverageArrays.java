
package averagearrays;

//James Anzuruni
public class AverageArrays {

  
    public static void main(String[] args) {
         int[] numArray = { 45, 67, 45, 20, 33, 45 };
        int sum = 0;
        
         for (int num:numArray) {
           sum += num;
        }
         int average = sum / numArray.length;
        System.out.println("The average is:" + average);
    }
    
}
