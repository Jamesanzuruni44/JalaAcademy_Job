
package specifyarraycontains;

import java.util.*; 
import java.io.*;
public class SpecifyArrayContains {

    
    public static void main(String[] args) {
        int[] array_nums = {50, 77, 12, 54, 11,60};
	System.out.println("Original Array: "+Arrays.toString(array_nums)); 
	System.out.println("Result: "+test(array_nums));
    }	
    public static boolean test(int[] numbers) {
    for (int number : numbers) {
      if (number == 12 || number == 23) {
        return false;
      }
    }
       return true;
    }
    
}
