/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package findsecondlargesnumbertarray;

/**
 *
 * @author nzulani
 */
public class FindSecondLargesNumbertArray {

 

    public static void main(String[] args) {
        int temp, size;
      int array[] = {10, 20, 25, 63,102, 96, 57};
      size = array.length;
      for(int i = 0; i<size; i++ ){
         for(int j = i+1; j<size; j++){

            if(array[i]>array[j]){
               temp = array[i];
               array[i] = array[j];
               array[j] = temp;
            }
         }
      }
     
 System.out.println("The second largest number is:: "+array[size-2]);
    
    }
}
