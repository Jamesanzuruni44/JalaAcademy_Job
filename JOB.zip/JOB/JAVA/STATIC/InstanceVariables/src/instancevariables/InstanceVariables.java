
package instancevariables;


public class InstanceVariables {

  public int instanceVariable = 10;
    public static void main(String[] args) {
       InstanceVariables test = new InstanceVariables();
      System.out.println(test.instanceVariable);
    }
    
}
