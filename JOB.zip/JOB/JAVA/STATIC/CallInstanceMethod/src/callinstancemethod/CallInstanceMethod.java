
package callinstancemethod;

import java.io.*;
public class CallInstanceMethod {

  //Static Method 
    public static void main(String[] args) {
         // Creating object of the class
        CallInstanceMethod obj = new CallInstanceMethod();          
        
          // Calling instance method
        obj.disp();  
        
        System.out.println("Calling Instance!");
    }
        
      // Instance method
    void disp()                                  
    {
          // Local variable
        int a = 20;                              
        System.out.println(a);
       
    }
    
}
