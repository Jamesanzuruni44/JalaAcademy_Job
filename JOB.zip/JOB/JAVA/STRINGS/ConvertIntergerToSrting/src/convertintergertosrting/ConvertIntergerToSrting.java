
package convertintergertosrting;

/**
 *
 * @author nzulani
 */
public class ConvertIntergerToSrting {

   
    public static void main(String[] args) {
   int num = 7;
  String value = String.valueOf(num);
  System.out.println("Value is " + value);
    }
    
}
