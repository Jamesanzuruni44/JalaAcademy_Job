
package concentstring;


public class ConcentString {

   
    public static void main(String[] args) {
        String s1 = "Hello";
      String s2 = "world";
      String res = s1+s2;
      System.out.print("Concatenation result:: ");
      System.out.println(res);
    }
    
}
