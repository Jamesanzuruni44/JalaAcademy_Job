
package classdefaultfield;


public class ClassDefaultField {

   
    public static void main(String[] args) {
        
       
    }
    
}
