
package evennumberusingwhile;
import java.util.Scanner;

public class EvenNumberUsingWhile {

   //Author: James Anzuruni
    
    public static void main(String[] args) {
           int oddNumber, a;
      Scanner sc = new Scanner(System.in);  
      System.out.println("Please enter limit to print odd numbers: ");  
      oddNumber = sc.nextInt();
      a = 1;
      System.out.println("Odd numbers: ");  
      
      while(a <= oddNumber)  
      {  
         System.out.println(a + " ");   
         a = a + 2;  
      }
      sc.close();
   }
        
    }
    

