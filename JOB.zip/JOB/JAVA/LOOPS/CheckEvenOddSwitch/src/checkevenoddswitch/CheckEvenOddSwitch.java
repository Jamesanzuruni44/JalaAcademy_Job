
package checkevenoddswitch;

/**
 *
 * @author:Anzuruni
 */
import java.util.Scanner;
public class CheckEvenOddSwitch {

   
    public static void main(String[] args) {
        Scanner Obbj= new Scanner(System.in);
        int number=0;
     System.out.printf("Enter a positive integer number: ");
    number = Obbj.nextInt();
    
     switch (number % 2) {
    case 0:
      System.out.println( ""+number+" Is Even Number");
      break;

    case 1:
      System.out.println( ""+number+" Is Not Even Number");
      break;
    }
       
    }
    
}
