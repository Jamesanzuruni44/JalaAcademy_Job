
package evenoddnumbers;
public class EvenOddNumbers {

   
    public static void main(String[] args) {
        System.out.println("\nEven numbers between 1 and 10: ");
      for(int a = 1; a <= 10; a++){
          
             if(a % 2 == 0)
         {
            System.out.println(a + " ");
         }
      }
      
          System.out.println("\nOdd numbers between 1 and 10: ");
      for(int a = 1; a <= 10; a++)
      {
         if(a % 2 != 0)
         {
            System.out.println(a + " ");
         }
      }
          
      }
    }
    

