
package definevariables;

/**
 *
 * @author:James Anzuruni.
 *
 * phone:+254796026154
 * 
 */
public class DefineVariables {
    public static void main(String[] args) {
    int a,b;
    a=5;b=10;
    System.out.println(a+b);
    
    float n,m;
    n=2.6f;m=6.9f;
    System.out.println(n+m);
    
    boolean option=false;
    System.out.println(option);
  
    String name="James";
    System.out.println(name);
    
    char me='k';
    System.out.println(me);
      
    }   
    
}
