

package functiontoprintname;

//import java.util.Scanner;

/**
 *
 * @author:James Anzuruni.
 * email:jamesanzuruniwilondja@gmail.com.
 * phone:+254796026154
 * 
 */
public class FunctionToPrintName {

    public static void main(String[] args) {
       // Scanner input= new Scanner(System.in);
        //System.out.println("Input My Name");
        String name="Jmaes";
        //String name =input.next();
        System.out.println();//I introduce this function to call my name.
        System.out.println("Hello Interviewer My is "+name);
    }
    
}
