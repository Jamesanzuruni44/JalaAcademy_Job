
package globallocalvariable;

/**
 *
 * @author Anzuruni
 */
public class GlobalLocalVariable {
    
    static String name="James"; //Global variables Declared and Initialized here.
    
    
    public static void main(String[] args) {
        System.out.println(""+name);
        
          String name="Anzu"; //Local variables declared and initialized
        System.out.println(name); 
    }
    
}
