
package printingmyname;

/**
 *
 * @author:James Anzuruni.
 * email:jamesanzuruniwilondja@gmail.com.
 * phone:+254796026154
 * 
 */
public class PrintingMyName {
    
    public static void main(String[] args) {
        
        // the printed name is my name
        System.out.println("James Anzuruni");
    }
    
}
