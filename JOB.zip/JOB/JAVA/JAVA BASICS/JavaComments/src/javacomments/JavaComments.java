
package javacomments;
/**
 *
 * @author:James Anzuruni.
 * email:jamesanzuruniwilondja@gmail.com.
 * phone:+254796026154
 * 
 */


public class JavaComments {

    public static void main(String[] args) {
        // This is Single Line Comments
        System.out.println("This is Single Line comment");
        
        
         /* 
            *This is Multiple Line Comments
        
        */
        System.out.println("This is multiple Line comment");
        
        /**
        *
         * This is the Documentation Comment
        */
        System.out.println("This Is Documentation Coments");
        
    }
    
}
