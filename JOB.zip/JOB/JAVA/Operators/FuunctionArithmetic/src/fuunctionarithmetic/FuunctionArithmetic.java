
package fuunctionarithmetic;

/**
 *
 * @author nzulani
 */
public class FuunctionArithmetic {
    public static void main(String[] args) {
        int a,b;
        a=28;b=13;
        
        int sum;
        sum=a+b;
        System.out.println(sum);
        
       int differ;
       differ=a-b;
       System.out.println(differ);
       
       int product;
       product=a*b;
       System.out.println(product);
       
       double quatient;
       quatient=a/b;
       System.out.println(quatient);
               
}
}   

